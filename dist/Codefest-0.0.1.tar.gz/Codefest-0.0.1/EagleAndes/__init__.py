from .text_recognition import *
from .video_recognition import *
